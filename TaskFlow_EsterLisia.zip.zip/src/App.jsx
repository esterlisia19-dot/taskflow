import "./App.css";
// import TarefaItem from "./componentes/TarefaItem";

import Header from './componentes/Header';s
import ListaTarefas from './componentes/ListaTarefas';
// import Contador  from './componentes/Contador';
import { useState } from 'react';
import { useState, useEffect } from 'react';


function App() {
  const [tarefas, setTarefas] = useState([]);
  const [proximoId, setProximoId] = useState(1);
  const [texto, setTexto] = useState('');
  const [prioridade, setPrioridade] = useState('media');
  const [filtro, setFiltro] = useState("Todas");
  
  useEffect(() => {
    const pendentes = tarefas.filter(t => !t.concluida).length;
    if (pendentes > 0) {
      document.title = '(' + pendentes + ') TaskFlow';
  } else {
  document.title = 'TaskFlow';
    }
  }, [tarefas]);

}

  const adicionarTarefa = () => {
    if (texto.trim() === '') { 
      return; //validacao
    };
  }
    const novaTarefa = {
      id: proximoId,
      texto: texto,
      concluida: false,
      prioridade: prioridade
    };
   
    setTarefas([...tarefas,novaTarefas]);
    setProximaId(proximaId + 1);
    setTexto(""); //Limpa o campo de input após adicionar a tarefa
    setPrioridade("media"); //Reseta a prioridade para o valor padrão
  
/*const pendentes = tarefas.filter((t) => !t.concluida).length;
if (pendentes > 0) {
  document.title = "(" + pendentes + ") TaskFlow";*/




  const deletarTarefa = (id) => {
    const tarefasAtualizadas = tarefas.filter(tarefa => tarefas.id !== id);
    setTarefas(tarefasAtualizadas);
  }
  const alterarConcluida = (id) => {
    const tarefasAtualizadas = tarefas.map(tarefa => {
      if (tarefa.id === id) {
        return { ...tarefa, concluida: !tarefas.concluida};
      }
      return tarefas;
  });
      setTarefas(tarefasAtualizadas);
  };
   const filtrarTarefas = (novoFiltro) => {
    setFiltro(novoFiltro);
  };
  const tarefasFiltradas = tarefas.filter ((tarefa) => {
    if (filtro === "pendentes") {
      return !tarefa.concluida;
    }
  

  if (filtro === "concluidas") { 
    return tarefa.concluida; 
  }

  return true;
});

    /*const nova = {
      id: proximoId,
      texto: texto.trim(),
      concluida: false,
      prioridade: 'media',

    };*/

    setTarefas([...tarefas, nova]);  // adiciona ao array
    setProximoId(proximoId + 1);      // incrementa o id
    setTexto('');

  // Array de objetos com os dados das tarefas
  // Cada tarefa tem: id unico, texto, concluida e prioridade

  
  return ( 
    <>
    
      <div id="app">
      <Header titulo="TaskFlow" subtitulo="Gerencie suas tarefas" tarefas={tarefasFiltradas}/>
      <main className="container">
        {/* Formulário de adicionar tarefa */}
        <section id="formulario">
          <div className="campo-linha">
            <input
              type="text"
              value={texto}
              onChange={e => setTexto(e.target.value)}
              onKeyDown={e => e.key === "Enter" && adicionarTarefa () }
              placeholder="Nova tarefa..."
              />
            <button onClick={adicionarTarefa}>Adicionar</button>
              </div>
              </section>
              
              < select id="sel-prioridade"
              value={prioridade}
              onChange={e => setPrioridade(e.target.value)}
              >
              <option value="alta">🔴 Alta</option>
              <option value="media">🟡 Média</option>
              <option value="baixa">🟢 Baixa</option>
            </select>
           
          
        

        
        {/* Filtros*/}
        <section id="controles">
          <div id="filtros">
            <button className="btn-filtro ativo" data-filtro="todas">
              Todas
            </button>
            <button className="btn-filtro" data-filtro="pendentes">
              Pendentes
            </button>
            <button className="btn-filtro" data-filtro="concluidas">
              Concluídas
            </button>
          </div>
        </section>

        {/* Lista de tarefas */}
        <ListaTarefas 
            tarefas={tarefasFiltradas} 
            onDeletar={deletarTarefa} 
            onConcluir={concluirTarefa}
        />
      </main>

      <footer>
        <p>
          TaskFlow &copy; 2026 &mdash; Prof. Alan Glei &mdash; SENAI CTGAS-ER
        </p>
      </footer>
      </div>
    </>
    
  );


export default App;
