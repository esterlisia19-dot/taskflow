import { useState } from 'react';

function Contador () {
    const [contador, setContador] = useState (0);
    
    return (
        <div>
            {/* <p>Valor: {contador}</p> */}
            <p>Valor: {contador}</p>
            <button onClick={() => setValor(valor + 1)}>
                Incrementar
            </button>
        </div>
    );

}