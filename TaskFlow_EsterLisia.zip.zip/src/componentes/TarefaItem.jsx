import styles from './TarefaItem.module.css';

function TarefaItem({ texto, concluida = false, prioridade = 'media', onDeletar, onConcluir }) {
  // Classe do li muda conforme o estado concluida
    const classItem = (concluida ? styles.tarefa + ' ' + styles.concluida : styles.tarefa) + ' ' + styles[prioridade];

  // Classe do texto tambem muda
  const classTexto = concluida ? styles.textoTarefa + ' ' + styles['texto-tarefa'] : styles.textoTarefa;

//   const classeTexto = concluida ? `${styles.textotarefa} ${styles["texto-tarefa"]}` : styles.textotarefa;
const  classPrioridade = styles['badge-prioridade'] + ' ' + styles['badge-' + prioridade];

  return (
    <li className={classItem} onClick={onConcluir}>
    
    <span className={classTexto}>{texto}</span>
    
    <span className={classPrioridade}>{prioridade}</span>
      
        
        
        
        <button className={styles.btnDeletar} onClick={(e) => {e.stopPropagation(); onDeletar(); }}> 
          X 
          </button>
          
    </li>
    
  );
}

export default TarefaItem;
