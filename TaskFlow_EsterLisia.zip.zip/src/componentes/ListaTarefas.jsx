import TarefasItem from "./TarefaItem";


function ListaTarefas({ tarefas }) {
    return (
        <section id='Lista-section'>
            {/*Mensagem quando nao ha tarefas*/}
            {tarefas.length === 0 && (
                <p className='msg-vazia'>
                    Nenhuma tarefa cadastrada. Adicione uma acima!
                </p>
            )}
            {/* Lista renderizada dinamicamente */}
            {tarefas.length > 0 && (
                <ul id='lista-tarefas'>
                    {tarefas.map(tarefa => (
                        <TarefaItem
                            key={tarefas.id}
                            texto={tarefas.texto}
                            concluida={tarefas.concluida}
                            prioridade={tarefas.prioridade}
                            onDeletar={() => onDeletar (tarefas.id)}
                            onConcluir={() => onConcluir (tarefas.id)}
                        />
                    ))}
                </ul>
            )}
        </section>
    );
}
export default ListaTarefas;