import { useState } from "react";
import { Route, Routes } from "react-router";
import "./App.css";
import Kanban from "./pages/kanban";
import Sobre from "./pages/sobre";
import Login from "./pages/login";
import Sidebar from "./componentes/sidebar";
import RotaPrivada from "./componentes/RotaPrivada";

function App() {

  const [logado, setLogado] = useState(false);

  return (
    <div className="app-layout">
      {/* Sidebar fica FORA do Routes — aparece em todas as páginas */}
      <Sidebar logado={logado} onLogout={() => setLogado(false)} />

      {/* Conteúdo principal — muda conforme a URL */}
      <main className="app-conteudo">
        <Routes>
          <Route path="/" element={<RotaPrivada logado={logado}><Kanban /></RotaPrivada>} />
          <Route path="/sobre" element={<Sobre />} />
          <Route path="/login" element={<Login onLogin={() => setLogado(true)} />} />
          <Route path="*" element={<h1>Página não encontrada</h1>} />
        </Routes>
      </main>
    </div>
  );
}

export default App;


