import { useState } from 'react';
import { useNavigate } from 'react-router';
import './Login.css';

function Login({ onLogin }) {
const [usuario, setUsuario] = useState('');
const [senha, setSenha] = useState('');
const [erro, setErro] = useState('');

// useNavigate retorna uma função de navegação
// Chamamos essa função DENTRO de handleLogin (evento)
// Nunca no return — lá usaríamos <Navigate> em vez disso
const navigate = useNavigate();

function handleLogin() {

// Credenciais fixas — apenas para fins didáticos
// Autenticação real com banco de dados vem no back-end
   if (usuario === 'admin' && senha === '1234') {
     onLogin(); // atualiza o estado no App.jsx
     navigate('/'); // redireciona — chamado APÓS a ação
     return;
     
    }
    // Credenciais erradas → exibe mensagem de erro
   setErro('Usuário ou senha incorretos');
}


return (

<div className='login-container'>
<div className='login-card'>
<h1 className='login-logo'>TaskFlow</h1>
<p className='login-subtitulo'>Faça login para continuar</p>


<input className='login-input' 
type='text'
placeholder='Usuário' 
value={usuario}
onChange={e => setUsuario(e.target.value)} />


<input className='login-input' 
type='password'
placeholder='Senha' 
value={senha}
onChange={e => setSenha(e.target.value)}
onKeyDown={e => e.key === 'Enter' && handleLogin()} />


{erro && <p className='login-erro'>{erro}</p>}

<button className='login-btn' onClick={handleLogin}>
Entrar
</button>

<p className='login-aviso'>
Este login é apenas para fins didáticos.Credenciais reais vêm no 
módulo back-end.

</p>
 </div>
</div>

);
}
export default Login;
