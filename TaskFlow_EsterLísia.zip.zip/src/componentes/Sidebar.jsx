import { NavLink } from 'react-router';
import styles from './Sidebar.module.css';

function Sidebar({ logado, onLogout }) {
const linkClass = ({ isActive }) =>

    IsActive ? styles.link + ' ' + styles.ativo : styles.link;

return (
(<aside className={styles.sidebar}>
   <div className={styles.logo}>
    <h1>TaskFlow</h1>
    </div>
    <nav className={styles.nav}>
        {logado && <NavLink to='/' className={linkClass}>Dashboard</NavLink>}
        <NavLink to='/sobre' className={linkClass}>Sobre</NavLink>
        </nav>
        {logado && (
        <button className={styles.logout} onClick={onLogout}>
        Sair 
        </button>
        )}
    </aside>)
);
}  



export default Sidebar;