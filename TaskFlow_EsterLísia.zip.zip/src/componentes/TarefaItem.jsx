import styles from './TarefaItem.module.css';

function TarefaItem({ texto, concluida = false, prioridade = 'media', onDeletar, onConcluir, onMover= null, 
  colunaAnterior= null, colunaProxima= null }) {
  // Classe do li muda conforme o estado concluida
    const classeItem = (concluida ? styles.tarefa + ' ' + styles.concluida : styles.tarefa) + ' ' + styles[prioridade];

  // Classe do texto tambem muda
  const classeTexto = concluida ? styles.textoTarefa + ' ' + styles['texto-tarefa'] : styles.textoTarefa;

//   const classeTexto = concluida ? `${styles.textotarefa} ${styles["texto-tarefa"]}` : styles.textotarefa;
const  classePrioridade = styles['badge-prioridade'] + ' ' + styles['badge-' + prioridade];

const modoKanban = onMover !== null;

  return (
    <li className={classeItem}>
     <span className={classeTexto} onDoubleClick={onConcluir}>{texto}</span>
    <span className={classePrioridade}>{prioridade}</span>
           {/*<button className={styles.btnDeletar} onClick={onDeletar}>
             X
           </button>*/}
        <div classeName={styles.acoes}>

          {modoKanban && colunaAnterior && (
            <button 
            className={styles.btnMover}
            onClick={() => onMover(colunaAnterior)}
            title="Mover para coluna anterior"
            >
              ←
              </button>
          )}

          <button className={styles.btnDeletar} onClick={onDeletar}>
            X
          </button>
        
        
        
        {/*<button className={styles.btnDeletar} onClick={(e) => {e.stopPropagation(); onDeletar(); }}> 
          X 
          </button>*/}
          </div>
    </li>
    
  );
}

export default TarefaItem;
