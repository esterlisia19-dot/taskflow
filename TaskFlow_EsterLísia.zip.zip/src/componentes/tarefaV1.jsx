import "./App.css";
// import TarefaItem from "./componentes/TarefaItem";
import Header from './Header';
import ListaTarefas from './ListaTarefas';
// import Contador  from './componentes/Contador';
import { useState, useEffect } from 'react';
import TarefasV1 from "./tarefaV1";

function TarefasV1() {
const [proximaId, setProximaId] = useState(1);
const [tarefas, setTarefas] = useState(() => {
const tarefasSalvas = localStorage.getItem("tarefas");

    if (!tareafasSalvas) {
        return [];
    }
const tarefasConvertidas = JSON.parse(tarefasSalvas);
setProximaId(
    tarefasConvertidas.length > 0
    ? tarefasConvertidas[tarefasConvertidas.length - 1].id + 1
    : 1,
    );
    return Array.isArray(tarefasConvertidas) ? tarefasConvertidas : [];
});

const [texto, setTexto] = useState("");
const [prioridade, setPrioridade] = useState("media");

const [filtro, setFiltro] = useState("todas");

useEffect(() => {
    localStorage.setItem("tarefas", JSON.stringify(tarefas));
}, [tarefas]);

const adicionarTarefa = () => {
    if (texto.trim() === "") {
        return;
    }

   const novaTarefa = {
    id: proximaId,
    texto: texto,
    concluida: false,
    prioridade: prioridade,
};
setTarefas([...tarefas, novaTarefa]);
setProximaId(proximaId + 1);
setTexto("");
setPrioridade("media");
// const pendentes = tarefas.filter((t) => !t.concluida).length;
    // if (pendentes > 0) {
    //   document.title = "(" + pendentes + ") TaskFlow";
    // } else {
    //   document.title = "TaskFlow";
    // }
};

const deletarTarefa = (id) => {
    const tarefasAtualizadas = tarefas.filter((tarefa) => tarefa.id !== id);
    setTarefas(tarefasAtualizadas);
};

const alternarConcluida = (id) => {
    const tarefasAtualizadas = tarefas.map((tarefa) => {
        if (tarefa.id === id) {
            return { ...tarefa, concluida: !tarefa.concluida};
        }
        return tarefa;
    });
    setTarefas(tarefasAtualizadas);
};

const filtrarTarefas = (novoFiltro) => {
    setFiltro(novoFiltro);
};

const tarefasFiltradas = tarefas.filter((tarefa) => {
    if (filtro === "pendentes") {
        return !tarefa.concluida;
    }

    if (filtro === "concluidas") {
        return tarefa.concluida;
    }

    return true;
});

return (
    <>
      <Contador/>
      <Header
        titulo="TaskFlow - Teste"
        subtitulo="Grencie suas tarefas"
        tarefas={tarefas}
        />
        <main className="container">
            <section id="formulario">
                <div className="campo-linha">
                    <input
                    id="input-tarefa"
                    type="text"
                    placeholder="Nova tarefa..."
                    required
                    autoComplete="off"
                    value={texto}
                    onChange={(e) => setTexto(e.target.value)}
                    />
                    <select 
                    id="sel-prioridade"
                    value={prioridade}
                    onChange={(e) => setPrioridade(e.target.value)}
                    >
                        <option value="Alta">🔴 Alta</option>
                        <option value="Media">🟡Media</option>
                        <option value="Baixa">🟢Baixa</option>
                    </select>

                    <button id="btn-adicionar" type="button" onClick={adicionarTarefa}>
                        Adicionar
                    </button>
                </div>
            </section>
            {/*Filtros*/}
            <section id="controles">
                <div id="filtros">
                    <button 
                    className={filtro === "todas" ? "btn-filtro ativo" : "btn-filtro"
                    }
                    data-filtro="todas"
                    onClick={() => filtrarTarefas("todas")}
                    >
                        Todas
                    </button>
                    
                    <button
                    className={
                        filtro === "pendentes" ? "btn-filtro ativo" : "btn-filtro"}
                        data-filtro="pendentes"
                        onClick={() => filtrarTarefas("pendentes")}
                        >
                            Pendentes
                        </button>
                        
                        <button
                        className={filtro === "concluidas" ? "btn-filtro ativo" : "btn-filtro"
                        }
                        data-filtro="concluidas"
                        onClick={() => filtrarTarefas("concluidas")}
                        >
                         Concluidas
                        </button>
                    </div>
                </section>
                {/*Lista Tarefas*/}
                <ListaTarefas
                tarefas={tarefasFiltradas}
                onDeletar={deletarTarefa}
                onCloncluir={alternarConcluida}
                />
            </main>
            <footer>
             <p>
                TaskFlow &copy; 2026 &mdash; Prof.Alan Glei &mdash; SENAI CTGAS-ER
             </p>
           </footer>
        </>
        );
    }  
    
export default TarefaV1; 
